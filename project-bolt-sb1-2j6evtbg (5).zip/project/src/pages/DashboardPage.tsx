import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/hooks/useAuth';
import { useAppointments } from '@/hooks/useAppointments';
import { AppointmentList } from '@/components/appointments/AppointmentList';
import { PropertyCard } from '@/components/properties/PropertyCard';
import { useProperties } from '@/hooks/useProperties';

export function DashboardPage() {
  const { user } = useAuth();
  const { data: appointments, isLoading: appointmentsLoading } = useAppointments(user?.uid || '');
  const { data: savedProperties } = useProperties({ userId: user?.uid });
  const [activeTab, setActiveTab] = useState('appointments');

  const handleJoinCall = (appointment: any) => {
    // Implement video/audio call functionality
    console.log('Joining call for appointment:', appointment);
  };

  if (appointmentsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Dashboard</h1>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-8">
          <TabsTrigger value="appointments">Appointments</TabsTrigger>
          <TabsTrigger value="saved">Saved Properties</TabsTrigger>
          <TabsTrigger value="alerts">Property Alerts</TabsTrigger>
        </TabsList>

        <TabsContent value="appointments">
          <div className="space-y-6">
            <h2 className="text-xl font-semibold">Your Appointments</h2>
            {appointments && appointments.length > 0 ? (
              <AppointmentList
                appointments={appointments}
                onJoinCall={handleJoinCall}
              />
            ) : (
              <p className="text-gray-600">No appointments scheduled.</p>
            )}
          </div>
        </TabsContent>

        <TabsContent value="saved">
          <div className="space-y-6">
            <h2 className="text-xl font-semibold">Saved Properties</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {savedProperties?.map((property) => (
                <PropertyCard key={property.id} property={property} />
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="alerts">
          <div className="space-y-6">
            <h2 className="text-xl font-semibold">Property Alerts</h2>
            {/* Implement property alerts UI */}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}