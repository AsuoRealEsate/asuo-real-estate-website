import { Link } from 'react-router-dom';
import { Search, Building2, TrendingUp, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section 
        className="relative h-[600px] bg-cover bg-center"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&q=80")'
        }}
      >
        <div className="absolute inset-0 bg-black/50" />
        <div className="relative container mx-auto px-4 h-full flex flex-col justify-center items-center text-center text-white">
          <h1 className="text-5xl font-bold mb-6">Find Your Dream Property</h1>
          <p className="text-xl mb-8 max-w-2xl">
            Discover the perfect property with ASUO Real Estate. Whether you're buying, selling, or investing,
            we're here to guide you every step of the way.
          </p>
          <div className="flex gap-4">
            <Link to="/properties">
              <Button size="lg">Browse Properties</Button>
            </Link>
            <Link to="/register">
              <Button variant="outline" size="lg">Get Started</Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose ASUO Real Estate?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <Search className="mx-auto h-12 w-12 text-primary mb-4" />
              <h3 className="text-xl font-semibold mb-2">Smart Property Search</h3>
              <p className="text-gray-600">
                Advanced search features to help you find exactly what you're looking for
              </p>
            </div>
            <div className="text-center p-6">
              <Building2 className="mx-auto h-12 w-12 text-primary mb-4" />
              <h3 className="text-xl font-semibold mb-2">Virtual Tours</h3>
              <p className="text-gray-600">
                Explore properties from anywhere with our immersive virtual tours
              </p>
            </div>
            <div className="text-center p-6">
              <TrendingUp className="mx-auto h-12 w-12 text-primary mb-4" />
              <h3 className="text-xl font-semibold mb-2">Market Insights</h3>
              <p className="text-gray-600">
                Stay informed with real-time market data and expert analysis
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Start Your Journey?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of satisfied clients who found their perfect property with ASUO Real Estate
          </p>
          <Link to="/register">
            <Button size="lg" variant="outline">
              Create Your Account
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}