import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { Button } from '@/components/ui/button';
import { Bed, Bath, Square, MapPin, Phone, Mail, Calendar } from 'lucide-react';
import type { Property } from '@/types/property';

export function PropertyDetailsPage() {
  const { id } = useParams<{ id: string }>();
  
  const { data: property, isLoading } = useQuery({
    queryKey: ['property', id],
    queryFn: async () => {
      const docRef = doc(db, 'properties', id!);
      const docSnap = await getDoc(docRef);
      if (!docSnap.exists()) {
        throw new Error('Property not found');
      }
      return { id: docSnap.id, ...docSnap.data() } as Property;
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!property) {
    return (
      <div className="flex items-center justify-center min-h-screen text-red-600">
        Property not found
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Image Gallery */}
        <div className="space-y-4">
          <img
            src={property.images[0]}
            alt={property.title}
            className="w-full h-[400px] object-cover rounded-lg"
          />
          <div className="grid grid-cols-4 gap-2">
            {property.images.slice(1).map((image, index) => (
              <img
                key={index}
                src={image}
                alt={`${property.title} - ${index + 2}`}
                className="w-full h-24 object-cover rounded-lg cursor-pointer"
              />
            ))}
          </div>
        </div>

        {/* Property Details */}
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold mb-2">{property.title}</h1>
            <div className="flex items-center text-gray-600">
              <MapPin className="h-5 w-5 mr-2" />
              <span>
                {property.location.address}, {property.location.city}, {property.location.state}
              </span>
            </div>
            <div className="mt-4 text-2xl font-bold text-primary">
              ${property.price.toLocaleString()}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 py-4 border-y border-gray-200">
            <div className="flex items-center">
              <Bed className="h-5 w-5 mr-2 text-gray-600" />
              <span>{property.features.bedrooms} Bedrooms</span>
            </div>
            <div className="flex items-center">
              <Bath className="h-5 w-5 mr-2 text-gray-600" />
              <span>{property.features.bathrooms} Bathrooms</span>
            </div>
            <div className="flex items-center">
              <Square className="h-5 w-5 mr-2 text-gray-600" />
              <span>{property.features.area} sqft</span>
            </div>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-2">Description</h2>
            <p className="text-gray-600">{property.description}</p>
          </div>

          {/* Agent Information */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex items-center space-x-4">
              <img
                src={property.agent.photo}
                alt={property.agent.name}
                className="w-16 h-16 rounded-full object-cover"
              />
              <div>
                <h3 className="font-semibold">{property.agent.name}</h3>
                <div className="flex items-center text-gray-600 text-sm mt-1">
                  <Phone className="h-4 w-4 mr-1" />
                  <span>{property.agent.phone}</span>
                </div>
                <div className="flex items-center text-gray-600 text-sm">
                  <Mail className="h-4 w-4 mr-1" />
                  <span>{property.agent.email}</span>
                </div>
              </div>
            </div>
            <div className="mt-4 flex space-x-4">
              <Button className="flex-1">
                <Phone className="h-4 w-4 mr-2" />
                Call Agent
              </Button>
              <Button variant="outline" className="flex-1">
                <Calendar className="h-4 w-4 mr-2" />
                Schedule Viewing
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}