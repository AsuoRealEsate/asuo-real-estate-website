export interface PropertyAlert {
  id: string;
  userId: string;
  propertyType: 'house' | 'apartment' | 'condo' | 'land';
  minPrice?: number;
  maxPrice?: number;
  location: string;
  bedrooms?: number;
  bathrooms?: number;
  notificationPreference: 'email' | 'sms' | 'both';
  status: 'active' | 'paused' | 'deleted';
  createdAt: string;
}