export interface Appointment {
  id: string;
  userId: string;
  propertyId: string;
  agentId: string;
  date: string;
  time: string;
  type: 'video' | 'audio' | 'in-person';
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  paymentStatus: 'pending' | 'paid';
  paymentAmount: number;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}