export interface Payment {
  id: string;
  amount: number;
  description: string;
  status: 'pending' | 'completed' | 'failed';
  paymentMethod: {
    type: 'card';
    last4: string;
  };
  createdAt: string;
}