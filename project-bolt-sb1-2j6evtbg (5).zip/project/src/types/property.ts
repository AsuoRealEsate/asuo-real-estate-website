export interface Property {
  id: string;
  title: string;
  description: string;
  price: number;
  location: {
    address: string;
    city: string;
    state: string;
    country: string;
    coordinates: {
      latitude: number;
      longitude: number;
    };
  };
  features: {
    bedrooms: number;
    bathrooms: number;
    area: number; // in square feet
    yearBuilt: number;
  };
  amenities: string[];
  type: 'house' | 'apartment' | 'condo' | 'land';
  status: 'for-sale' | 'for-rent' | 'sold' | 'rented';
  images: string[];
  virtualTour?: string;
  agent: {
    id: string;
    name: string;
    email: string;
    phone: string;
    photo: string;
  };
  createdAt: string;
  updatedAt: string;
}