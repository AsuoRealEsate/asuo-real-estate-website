import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/useToast';
import { usePayments } from '@/hooks/usePayments';
import { CreditCard, Lock } from 'lucide-react';

const paymentSchema = z.object({
  cardNumber: z.string().regex(/^\d{16}$/, 'Invalid card number'),
  expiryDate: z.string().regex(/^(0[1-9]|1[0-2])\/([0-9]{2})$/, 'Invalid expiry date'),
  cvv: z.string().regex(/^\d{3,4}$/, 'Invalid CVV'),
  name: z.string().min(1, 'Name is required'),
});

type PaymentFormData = z.infer<typeof paymentSchema>;

interface PaymentFormProps {
  amount: number;
  description: string;
  onSuccess: (transactionId: string) => void;
}

export function PaymentForm({ amount, description, onSuccess }: PaymentFormProps) {
  const [loading, setLoading] = useState(false);
  const { processPayment } = usePayments();
  const { toast } = useToast();

  const { register, handleSubmit, formState: { errors } } = useForm<PaymentFormData>({
    resolver: zodResolver(paymentSchema),
  });

  const onSubmit = async (data: PaymentFormData) => {
    try {
      setLoading(true);
      const result = await processPayment.mutateAsync({
        amount,
        description,
        paymentMethod: {
          type: 'card',
          ...data,
        },
      });
      
      toast({
        title: 'Payment Successful',
        description: 'Your payment has been processed successfully.',
      });
      
      onSuccess(result.transactionId);
    } catch (error) {
      toast({
        title: 'Payment Failed',
        description: 'There was an error processing your payment.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="bg-primary/5 p-4 rounded-lg mb-6">
        <div className="flex justify-between items-center">
          <span className="text-sm font-medium">Amount to Pay</span>
          <span className="text-lg font-bold">${amount.toFixed(2)}</span>
        </div>
        <p className="text-sm text-gray-600 mt-1">{description}</p>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Card Number</label>
        <div className="mt-1 relative">
          <input
            type="text"
            {...register('cardNumber')}
            className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-primary focus:border-primary"
            placeholder="1234 5678 9012 3456"
          />
          <CreditCard className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
        </div>
        {errors.cardNumber && (
          <p className="mt-1 text-sm text-red-600">{errors.cardNumber.message}</p>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Expiry Date</label>
          <input
            type="text"
            {...register('expiryDate')}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-primary focus:border-primary"
            placeholder="MM/YY"
          />
          {errors.expiryDate && (
            <p className="mt-1 text-sm text-red-600">{errors.expiryDate.message}</p>
          )}
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700">CVV</label>
          <input
            type="password"
            {...register('cvv')}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-primary focus:border-primary"
            placeholder="123"
          />
          {errors.cvv && (
            <p className="mt-1 text-sm text-red-600">{errors.cvv.message}</p>
          )}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Name on Card</label>
        <input
          type="text"
          {...register('name')}
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-primary focus:border-primary"
          placeholder="John Doe"
        />
        {errors.name && (
          <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>
        )}
      </div>

      <div className="flex items-center text-sm text-gray-600 mt-4">
        <Lock className="h-4 w-4 mr-2" />
        <span>Your payment information is secure and encrypted</span>
      </div>

      <Button
        type="submit"
        className="w-full"
        disabled={loading}
      >
        {loading ? 'Processing...' : `Pay $${amount.toFixed(2)}`}
      </Button>
    </form>
  );
}