import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { usePropertyAlerts } from '@/hooks/usePropertyAlerts';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';

const alertSchema = z.object({
  propertyType: z.enum(['house', 'apartment', 'condo', 'land']),
  minPrice: z.number().min(0).optional(),
  maxPrice: z.number().min(0).optional(),
  location: z.string(),
  bedrooms: z.number().min(0).optional(),
  bathrooms: z.number().min(0).optional(),
  notificationPreference: z.enum(['email', 'sms', 'both']),
});

type AlertFormData = z.infer<typeof alertSchema>;

export function PropertyAlertForm() {
  const { user } = useAuth();
  const { createAlert } = usePropertyAlerts(user?.uid || '');
  const { toast } = useToast();

  const { register, handleSubmit, formState: { errors } } = useForm<AlertFormData>({
    resolver: zodResolver(alertSchema),
  });

  const onSubmit = async (data: AlertFormData) => {
    try {
      await createAlert.mutateAsync({
        ...data,
        userId: user?.uid || '',
        createdAt: new Date().toISOString(),
        status: 'active'
      });
      toast({
        title: 'Success',
        description: 'Property alert created successfully.',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to create property alert.',
        variant: 'destructive',
      });
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700">Property Type</label>
        <select
          {...register('propertyType')}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
        >
          <option value="house">House</option>
          <option value="apartment">Apartment</option>
          <option value="condo">Condo</option>
          <option value="land">Land</option>
        </select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Min Price</label>
          <input
            type="number"
            {...register('minPrice', { valueAsNumber: true })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Max Price</label>
          <input
            type="number"
            {...register('maxPrice', { valueAsNumber: true })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Location</label>
        <input
          type="text"
          {...register('location')}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Notification Preference</label>
        <select
          {...register('notificationPreference')}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
        >
          <option value="email">Email</option>
          <option value="sms">SMS</option>
          <option value="both">Both</option>
        </select>
      </div>

      <Button type="submit" className="w-full">
        Create Alert
      </Button>
    </form>
  );
}