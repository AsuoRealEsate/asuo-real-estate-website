import { usePropertyAlerts } from '@/hooks/usePropertyAlerts';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Bell, Trash2 } from 'lucide-react';

export function PropertyAlertList() {
  const { user } = useAuth();
  const { alerts, deleteAlert } = usePropertyAlerts(user?.uid || '');

  if (alerts.isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {alerts.data?.map((alert) => (
        <div
          key={alert.id}
          className="bg-white rounded-lg shadow-sm p-4 flex items-center justify-between"
        >
          <div className="flex items-center space-x-4">
            <Bell className="h-5 w-5 text-primary" />
            <div>
              <h3 className="font-medium">{alert.propertyType} in {alert.location}</h3>
              <p className="text-sm text-gray-600">
                Price Range: ${alert.minPrice?.toLocaleString()} - ${alert.maxPrice?.toLocaleString()}
              </p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => deleteAlert.mutate(alert.id)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ))}
    </div>
  );
}