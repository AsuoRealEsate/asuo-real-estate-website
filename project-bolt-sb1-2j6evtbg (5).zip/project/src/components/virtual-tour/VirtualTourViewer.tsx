import { useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Maximize2, Minimize2, RotateCcw } from 'lucide-react';

interface VirtualTourViewerProps {
  tourUrl: string;
  onClose: () => void;
}

export function VirtualTourViewer({ tourUrl, onClose }: VirtualTourViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  return (
    <div ref={containerRef} className="relative w-full h-[600px] bg-black">
      <iframe
        src={tourUrl}
        className="w-full h-full border-0"
        allow="xr-spatial-tracking; gyroscope; accelerometer"
        allowFullScreen
      />
      
      <div className="absolute bottom-4 right-4 flex space-x-2">
        <Button
          variant="secondary"
          size="sm"
          onClick={toggleFullscreen}
        >
          {isFullscreen ? (
            <Minimize2 className="h-4 w-4" />
          ) : (
            <Maximize2 className="h-4 w-4" />
          )}
        </Button>
        <Button
          variant="secondary"
          size="sm"
          onClick={() => {
            // Reset view to initial position
            const iframe = containerRef.current?.querySelector('iframe');
            iframe?.contentWindow?.postMessage({ type: 'resetView' }, '*');
          }}
        >
          <RotateCcw className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}