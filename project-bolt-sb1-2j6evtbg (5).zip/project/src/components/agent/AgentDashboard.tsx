import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/hooks/useAuth';
import { useAgentListings } from '@/hooks/useAgentListings';
import { PropertyCard } from '@/components/properties/PropertyCard';
import { Button } from '@/components/ui/button';
import { Plus, Users, DollarSign, Building } from 'lucide-react';
import { ListingForm } from './ListingForm';
import { ClientList } from './ClientList';
import { CommissionTracker } from './CommissionTracker';

export function AgentDashboard() {
  const { user } = useAuth();
  const { data: listings } = useAgentListings(user?.uid || '');
  const [showListingForm, setShowListingForm] = useState(false);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Agent Dashboard</h1>
        <Button onClick={() => setShowListingForm(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Listing
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Active Listings</h3>
            <Building className="h-6 w-6 text-primary" />
          </div>
          <p className="text-2xl font-bold">{listings?.length || 0}</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Active Clients</h3>
            <Users className="h-6 w-6 text-primary" />
          </div>
          <p className="text-2xl font-bold">12</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Total Commission</h3>
            <DollarSign className="h-6 w-6 text-primary" />
          </div>
          <p className="text-2xl font-bold">$24,500</p>
        </div>
      </div>

      <Tabs defaultValue="listings">
        <TabsList>
          <TabsTrigger value="listings">My Listings</TabsTrigger>
          <TabsTrigger value="clients">Clients</TabsTrigger>
          <TabsTrigger value="commissions">Commissions</TabsTrigger>
        </TabsList>

        <TabsContent value="listings">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {listings?.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="clients">
          <ClientList />
        </TabsContent>

        <TabsContent value="commissions">
          <CommissionTracker />
        </TabsContent>
      </Tabs>

      {showListingForm && (
        <ListingForm
          onClose={() => setShowListingForm(false)}
          onSuccess={() => {
            setShowListingForm(false);
            // Refresh listings
          }}
        />
      )}
    </div>
  );
}