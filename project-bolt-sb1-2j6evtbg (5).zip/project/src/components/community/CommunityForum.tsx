import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { collection, addDoc, query, orderBy, getDocs } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { MessageSquare, Flag, ThumbsUp } from 'lucide-react';

interface ForumPost {
  id: string;
  userId: string;
  userName: string;
  content: string;
  likes: number;
  createdAt: string;
  replies: ForumReply[];
}

interface ForumReply {
  id: string;
  userId: string;
  userName: string;
  content: string;
  createdAt: string;
}

export function CommunityForum() {
  const { user } = useAuth();
  const [newPost, setNewPost] = useState('');
  const queryClient = useQueryClient();

  const { data: posts, isLoading } = useQuery({
    queryKey: ['forumPosts'],
    queryFn: async () => {
      const q = query(collection(db, 'forumPosts'), orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as ForumPost[];
    }
  });

  const createPost = useMutation({
    mutationFn: async (content: string) => {
      await addDoc(collection(db, 'forumPosts'), {
        userId: user?.uid,
        userName: user?.displayName,
        content,
        likes: 0,
        createdAt: new Date().toISOString(),
        replies: []
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['forumPosts'] });
      setNewPost('');
    }
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h2 className="text-2xl font-bold mb-8">Community Forum</h2>

      {user && (
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <textarea
            value={newPost}
            onChange={(e) => setNewPost(e.target.value)}
            placeholder="Share your thoughts with the community..."
            className="w-full p-4 border rounded-lg mb-4 min-h-[100px]"
          />
          <Button
            onClick={() => createPost.mutate(newPost)}
            disabled={!newPost.trim()}
          >
            Post
          </Button>
        </div>
      )}

      <div className="space-y-6">
        {posts?.map((post) => (
          <div key={post.id} className="bg-white rounded-lg shadow-md p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-semibold">{post.userName}</h3>
                <p className="text-gray-600 text-sm">
                  {new Date(post.createdAt).toLocaleDateString()}
                </p>
              </div>
              <Button variant="ghost" size="sm">
                <Flag className="h-4 w-4" />
              </Button>
            </div>

            <p className="mb-4">{post.content}</p>

            <div className="flex items-center space-x-4 text-gray-600">
              <button className="flex items-center space-x-1">
                <ThumbsUp className="h-4 w-4" />
                <span>{post.likes}</span>
              </button>
              <button className="flex items-center space-x-1">
                <MessageSquare className="h-4 w-4" />
                <span>{post.replies.length}</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}