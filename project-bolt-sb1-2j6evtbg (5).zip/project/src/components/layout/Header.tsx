import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Building2, Menu, X } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, signOut } = useAuth();

  return (
    <header className="bg-white shadow-sm">
      <nav className="container mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <Building2 className="h-8 w-8 text-primary" />
          <span className="text-xl font-bold">ASUO Real Estate</span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-6">
          <Link to="/properties" className="text-gray-600 hover:text-primary">Properties</Link>
          <Link to="/agents" className="text-gray-600 hover:text-primary">Agents</Link>
          <Link to="/market-insights" className="text-gray-600 hover:text-primary">Market Insights</Link>
          {user ? (
            <>
              <Link to="/dashboard" className="text-gray-600 hover:text-primary">Dashboard</Link>
              <Button onClick={() => signOut()} variant="outline">Sign Out</Button>
            </>
          ) : (
            <>
              <Link to="/login">
                <Button variant="outline">Sign In</Button>
              </Link>
              <Link to="/register">
                <Button>Register</Button>
              </Link>
            </>
          )}
        </div>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X /> : <Menu />}
        </button>
      </nav>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden px-4 py-2 space-y-2 bg-white">
          <Link to="/properties" className="block py-2 text-gray-600">Properties</Link>
          <Link to="/agents" className="block py-2 text-gray-600">Agents</Link>
          <Link to="/market-insights" className="block py-2 text-gray-600">Market Insights</Link>
          {user ? (
            <>
              <Link to="/dashboard" className="block py-2 text-gray-600">Dashboard</Link>
              <Button onClick={() => signOut()} variant="outline" className="w-full">Sign Out</Button>
            </>
          ) : (
            <>
              <Link to="/login" className="block">
                <Button variant="outline" className="w-full">Sign In</Button>
              </Link>
              <Link to="/register" className="block">
                <Button className="w-full">Register</Button>
              </Link>
            </>
          )}
        </div>
      )}
    </header>
  );
}