import { useEffect, useRef } from 'react';
import { Dialog } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Phone, Video, Mic, MicOff, VideoOff } from 'lucide-react';

interface VideoCallModalProps {
  isOpen: boolean;
  onClose: () => void;
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
}

export function VideoCallModal({
  isOpen,
  onClose,
  localStream,
  remoteStream,
}: VideoCallModalProps) {
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [localStream, remoteStream]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <div className="fixed inset-0 bg-black flex flex-col">
        <div className="flex-1 flex">
          {remoteStream && (
            <video
              ref={remoteVideoRef}
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />
          )}
        </div>
        
        <div className="absolute bottom-4 right-4 w-48 h-36">
          {localStream && (
            <video
              ref={localVideoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover rounded-lg"
            />
          )}
        </div>

        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-4">
          <Button
            variant="destructive"
            size="lg"
            className="rounded-full"
            onClick={onClose}
          >
            <Phone className="h-6 w-6" />
          </Button>
          <Button
            variant="secondary"
            size="lg"
            className="rounded-full"
          >
            <Video className="h-6 w-6" />
          </Button>
          <Button
            variant="secondary"
            size="lg"
            className="rounded-full"
          >
            <Mic className="h-6 w-6" />
          </Button>
        </div>
      </div>
    </Dialog>
  );
}