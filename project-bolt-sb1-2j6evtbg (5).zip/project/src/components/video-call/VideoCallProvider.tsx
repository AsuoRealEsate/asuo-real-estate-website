import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';

interface VideoCallContextType {
  startCall: (appointmentId: string) => Promise<void>;
  endCall: () => void;
  isCallActive: boolean;
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
}

const VideoCallContext = createContext<VideoCallContextType | null>(null);

export function VideoCallProvider({ children }: { children: React.ReactNode }) {
  const [isCallActive, setIsCallActive] = useState(false);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const peerConnection = useRef<RTCPeerConnection | null>(null);
  const { user } = useAuth();

  const initializePeerConnection = async () => {
    const pc = new RTCPeerConnection({
      iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
    });

    pc.ontrack = (event) => {
      setRemoteStream(event.streams[0]);
    };

    const stream = await navigator.mediaDevices.getUserMedia({
      video: true,
      audio: true
    });
    setLocalStream(stream);

    stream.getTracks().forEach(track => {
      pc.addTrack(track, stream);
    });

    peerConnection.current = pc;
  };

  const startCall = async (appointmentId: string) => {
    try {
      await initializePeerConnection();
      setIsCallActive(true);
      // Here you would implement the signaling logic with Firebase
    } catch (error) {
      console.error('Failed to start call:', error);
    }
  };

  const endCall = () => {
    localStream?.getTracks().forEach(track => track.stop());
    peerConnection.current?.close();
    setLocalStream(null);
    setRemoteStream(null);
    setIsCallActive(false);
  };

  useEffect(() => {
    return () => {
      endCall();
    };
  }, []);

  return (
    <VideoCallContext.Provider
      value={{
        startCall,
        endCall,
        isCallActive,
        localStream,
        remoteStream,
      }}
    >
      {children}
    </VideoCallContext.Provider>
  );
}