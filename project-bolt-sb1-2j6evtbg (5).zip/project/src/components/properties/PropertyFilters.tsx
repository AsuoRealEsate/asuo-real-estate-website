import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';

const filterSchema = z.object({
  type: z.enum(['all', 'house', 'apartment', 'condo', 'land']).default('all'),
  status: z.enum(['all', 'for-sale', 'for-rent']).default('all'),
  minPrice: z.number().min(0).optional(),
  maxPrice: z.number().min(0).optional(),
  location: z.string().optional(),
  sortBy: z.enum(['price', 'createdAt']).default('createdAt'),
  sortOrder: z.enum(['asc', 'desc']).default('desc'),
});

type FilterFormData = z.infer<typeof filterSchema>;

interface PropertyFiltersProps {
  onFilter: (filters: FilterFormData) => void;
}

export function PropertyFilters({ onFilter }: PropertyFiltersProps) {
  const { register, handleSubmit } = useForm<FilterFormData>({
    resolver: zodResolver(filterSchema),
    defaultValues: {
      type: 'all',
      status: 'all',
      sortBy: 'createdAt',
      sortOrder: 'desc',
    },
  });

  return (
    <form onSubmit={handleSubmit(onFilter)} className="bg-white p-4 rounded-lg shadow-md">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Type</label>
          <select
            {...register('type')}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
          >
            <option value="all">All Types</option>
            <option value="house">House</option>
            <option value="apartment">Apartment</option>
            <option value="condo">Condo</option>
            <option value="land">Land</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Status</label>
          <select
            {...register('status')}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
          >
            <option value="all">All Status</option>
            <option value="for-sale">For Sale</option>
            <option value="for-rent">For Rent</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Location</label>
          <input
            type="text"
            {...register('location')}
            placeholder="Enter city"
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Min Price</label>
          <input
            type="number"
            {...register('minPrice', { valueAsNumber: true })}
            placeholder="Min price"
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Max Price</label>
          <input
            type="number"
            {...register('maxPrice', { valueAsNumber: true })}
            placeholder="Max price"
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Sort By</label>
          <select
            {...register('sortBy')}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
          >
            <option value="createdAt">Date Listed</option>
            <option value="price">Price</option>
          </select>
        </div>
      </div>

      <div className="mt-4 flex justify-end">
        <Button type="submit">Apply Filters</Button>
      </div>
    </form>
  );
}