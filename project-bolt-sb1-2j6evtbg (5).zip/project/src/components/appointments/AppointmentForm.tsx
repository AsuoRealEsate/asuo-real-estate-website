import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { useCreateAppointment } from '@/hooks/useAppointments';
import { useToast } from '@/hooks/useToast';
import type { Property } from '@/types/property';

const appointmentSchema = z.object({
  date: z.string(),
  time: z.string(),
  type: z.enum(['video', 'audio', 'in-person']),
  notes: z.string().optional(),
});

type AppointmentFormData = z.infer<typeof appointmentSchema>;

interface AppointmentFormProps {
  property: Property;
  onSuccess: () => void;
}

export function AppointmentForm({ property, onSuccess }: AppointmentFormProps) {
  const [loading, setLoading] = useState(false);
  const { mutateAsync: createAppointment } = useCreateAppointment();
  const { toast } = useToast();

  const { register, handleSubmit, formState: { errors } } = useForm<AppointmentFormData>({
    resolver: zodResolver(appointmentSchema),
  });

  const onSubmit = async (data: AppointmentFormData) => {
    try {
      setLoading(true);
      await createAppointment({
        ...data,
        propertyId: property.id,
        agentId: property.agent.id,
        userId: 'current-user-id', // Replace with actual user ID
        status: 'pending',
        paymentStatus: 'pending',
        paymentAmount: 50, // Replace with actual consultation fee
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
      toast({
        title: 'Success',
        description: 'Appointment scheduled successfully.',
      });
      onSuccess();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to schedule appointment.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700">Date</label>
        <input
          type="date"
          {...register('date')}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
        />
        {errors.date && (
          <p className="mt-1 text-sm text-red-600">{errors.date.message}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Time</label>
        <input
          type="time"
          {...register('time')}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
        />
        {errors.time && (
          <p className="mt-1 text-sm text-red-600">{errors.time.message}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Type</label>
        <select
          {...register('type')}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
        >
          <option value="video">Video Call</option>
          <option value="audio">Audio Call</option>
          <option value="in-person">In-Person</option>
        </select>
        {errors.type && (
          <p className="mt-1 text-sm text-red-600">{errors.type.message}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Notes (Optional)</label>
        <textarea
          {...register('notes')}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
          rows={3}
        />
      </div>

      <Button type="submit" className="w-full" disabled={loading}>
        {loading ? 'Scheduling...' : 'Schedule Appointment'}
      </Button>

      <p className="text-sm text-gray-500 text-center mt-2">
        A consultation fee of $50 will be required upon confirmation
      </p>
    </form>
  );
}