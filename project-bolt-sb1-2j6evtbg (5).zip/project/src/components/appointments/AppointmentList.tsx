import { format } from 'date-fns';
import { Video, Phone, Users, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { Appointment } from '@/types/appointment';

interface AppointmentListProps {
  appointments: Appointment[];
  onJoinCall: (appointment: Appointment) => void;
}

export function AppointmentList({ appointments, onJoinCall }: AppointmentListProps) {
  const getAppointmentIcon = (type: Appointment['type']) => {
    switch (type) {
      case 'video':
        return <Video className="h-5 w-5" />;
      case 'audio':
        return <Phone className="h-5 w-5" />;
      case 'in-person':
        return <Users className="h-5 w-5" />;
    }
  };

  const getStatusColor = (status: Appointment['status']) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'confirmed':
        return 'bg-green-100 text-green-800';
      case 'completed':
        return 'bg-gray-100 text-gray-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
    }
  };

  return (
    <div className="space-y-4">
      {appointments.map((appointment) => (
        <div
          key={appointment.id}
          className="bg-white rounded-lg shadow-md p-4"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              {getAppointmentIcon(appointment.type)}
              <div>
                <h3 className="font-semibold">
                  {format(new Date(appointment.date), 'MMMM d, yyyy')}
                </h3>
                <p className="text-sm text-gray-600">
                  {format(new Date(`${appointment.date}T${appointment.time}`), 'h:mm a')}
                </p>
              </div>
            </div>
            <span
              className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(
                appointment.status
              )}`}
            >
              {appointment.status}
            </span>
          </div>

          {appointment.status === 'confirmed' && (
            <div className="mt-4">
              <Button
                onClick={() => onJoinCall(appointment)}
                className="w-full"
              >
                Join {appointment.type === 'video' ? 'Video' : 'Audio'} Call
              </Button>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}