export const es = {
  common: {
    search: 'Buscar',
    filter: 'Filtrar',
    sort: 'Ordenar',
    loading: 'Cargando...',
    error: 'Ocurrió un error',
    success: 'Éxito',
  },
  auth: {
    signIn: 'Iniciar Sesión',
    signUp: 'Registrarse',
    signOut: 'Cerrar Sesión',
    email: 'Correo Electrónico',
    password: 'Contraseña',
    forgotPassword: '¿Olvidaste tu contraseña?',
  },
  properties: {
    title: 'Propiedades',
    type: {
      house: 'Casa',
      apartment: 'Apartamento',
      condo: 'Condominio',
      land: 'Terreno',
    },
    features: {
      bedrooms: 'Habitaciones',
      bathrooms: 'Baños',
      area: 'Área',
    },
    status: {
      forSale: 'En Venta',
      forRent: 'En Alquiler',
      sold: 'Vendido',
      rented: 'Alquilado',
    },
  },
  alerts: {
    create: 'Crear Alerta',
    delete: 'Eliminar Alerta',
    notifications: {
      email: 'Correo',
      sms: 'SMS',
      both: 'Correo y SMS',
    },
  },
};