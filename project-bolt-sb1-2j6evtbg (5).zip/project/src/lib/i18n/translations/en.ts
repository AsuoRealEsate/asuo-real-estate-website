export const en = {
  common: {
    search: 'Search',
    filter: 'Filter',
    sort: 'Sort',
    loading: 'Loading...',
    error: 'An error occurred',
    success: 'Success',
  },
  auth: {
    signIn: 'Sign In',
    signUp: 'Sign Up',
    signOut: 'Sign Out',
    email: 'Email',
    password: 'Password',
    forgotPassword: 'Forgot Password?',
  },
  properties: {
    title: 'Properties',
    type: {
      house: 'House',
      apartment: 'Apartment',
      condo: 'Condo',
      land: 'Land',
    },
    features: {
      bedrooms: 'Bedrooms',
      bathrooms: 'Bathrooms',
      area: 'Area',
    },
    status: {
      forSale: 'For Sale',
      forRent: 'For Rent',
      sold: 'Sold',
      rented: 'Rented',
    },
  },
  alerts: {
    create: 'Create Alert',
    delete: 'Delete Alert',
    notifications: {
      email: 'Email',
      sms: 'SMS',
      both: 'Email & SMS',
    },
  },
};