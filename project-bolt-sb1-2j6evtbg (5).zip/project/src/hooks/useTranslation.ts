import { useCallback } from 'react';
import { en } from '@/lib/i18n/translations/en';
import { es } from '@/lib/i18n/translations/es';

const translations = {
  en,
  es,
};

type Language = keyof typeof translations;

export function useTranslation(language: Language = 'en') {
  const t = useCallback((key: string) => {
    const keys = key.split('.');
    let value = translations[language];
    
    for (const k of keys) {
      if (value?.[k]) {
        value = value[k];
      } else {
        return key;
      }
    }
    
    return value as string;
  }, [language]);

  return { t };
}