import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { collection, addDoc, query, where, getDocs, deleteDoc, doc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { PropertyAlert } from '@/types/propertyAlert';

export function usePropertyAlerts(userId: string) {
  const queryClient = useQueryClient();

  const alerts = useQuery({
    queryKey: ['propertyAlerts', userId],
    queryFn: async () => {
      const q = query(
        collection(db, 'propertyAlerts'),
        where('userId', '==', userId)
      );
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as PropertyAlert[];
    }
  });

  const createAlert = useMutation({
    mutationFn: async (alert: Omit<PropertyAlert, 'id'>) => {
      const docRef = await addDoc(collection(db, 'propertyAlerts'), alert);
      return { id: docRef.id, ...alert };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['propertyAlerts'] });
    }
  });

  const deleteAlert = useMutation({
    mutationFn: async (alertId: string) => {
      await deleteDoc(doc(db, 'propertyAlerts', alertId));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['propertyAlerts'] });
    }
  });

  return {
    alerts,
    createAlert,
    deleteAlert
  };
}