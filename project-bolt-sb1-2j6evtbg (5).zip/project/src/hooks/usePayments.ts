import { useMutation } from '@tanstack/react-query';
import { collection, addDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { Payment } from '@/types/payment';

interface ProcessPaymentParams {
  amount: number;
  description: string;
  paymentMethod: {
    type: 'card';
    cardNumber: string;
    expiryDate: string;
    cvv: string;
    name: string;
  };
}

export function usePayments() {
  const processPayment = useMutation({
    mutationFn: async (params: ProcessPaymentParams) => {
      // In a real application, you would integrate with a payment processor
      // like Stripe here. This is just a mock implementation.
      const payment: Omit<Payment, 'id'> = {
        amount: params.amount,
        description: params.description,
        status: 'completed',
        paymentMethod: {
          type: params.paymentMethod.type,
          last4: params.paymentMethod.cardNumber.slice(-4),
        },
        createdAt: new Date().toISOString(),
      };

      const docRef = await addDoc(collection(db, 'payments'), payment);
      return { transactionId: docRef.id };
    },
  });

  return { processPayment };
}