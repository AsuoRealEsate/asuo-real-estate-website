import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { collection, query, where, getDocs, addDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { Property } from '@/types/property';

export function useAgentListings(agentId: string) {
  return useQuery({
    queryKey: ['agentListings', agentId],
    queryFn: async () => {
      const q = query(
        collection(db, 'properties'),
        where('agent.id', '==', agentId)
      );
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Property[];
    }
  });
}

export function useCreateListing() {
  const queryClient = useQueryClient();

  return {
    createListing: useMutation({
      mutationFn: async (listing: Omit<Property, 'id'>) => {
        const docRef = await addDoc(collection(db, 'properties'), listing);
        return { id: docRef.id, ...listing };
      },
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ['agentListings'] });
      }
    })
  };
}