import { useQuery } from '@tanstack/react-query';
import { collection, getDocs, query, where, orderBy } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { Property } from '@/types/property';

interface UsePropertiesOptions {
  type?: Property['type'];
  status?: Property['status'];
  minPrice?: number;
  maxPrice?: number;
  location?: string;
  sortBy?: 'price' | 'createdAt';
  sortOrder?: 'asc' | 'desc';
}

export function useProperties(options: UsePropertiesOptions = {}) {
  return useQuery({
    queryKey: ['properties', options],
    queryFn: async () => {
      let q = collection(db, 'properties');
      
      // Build query based on filters
      if (options.type) {
        q = query(q, where('type', '==', options.type));
      }
      if (options.status) {
        q = query(q, where('status', '==', options.status));
      }
      if (options.minPrice) {
        q = query(q, where('price', '>=', options.minPrice));
      }
      if (options.maxPrice) {
        q = query(q, where('price', '<=', options.maxPrice));
      }
      if (options.location) {
        q = query(q, where('location.city', '==', options.location));
      }
      if (options.sortBy) {
        q = query(q, orderBy(options.sortBy, options.sortOrder || 'asc'));
      }

      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Property[];
    }
  });
}